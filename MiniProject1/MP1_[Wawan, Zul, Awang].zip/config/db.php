<?php
$host = "127.0.0.1:3307";
$user = "root";
$pass = "";
$dbname = "db_gms";

$conn = new mysqli($host, $user, $pass, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>